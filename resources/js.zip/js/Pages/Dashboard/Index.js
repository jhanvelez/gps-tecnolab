import Layout from '@/Shared/Layout';


const Dashboard = (props) => {

  return (
    <>
    </>
  );
};

// Persistent layout
// Docs: https://inertiajs.com/pages#persistent-layouts
Dashboard.layout = page => <Layout title="Dashboard" children={page} />;

export default Dashboard;

